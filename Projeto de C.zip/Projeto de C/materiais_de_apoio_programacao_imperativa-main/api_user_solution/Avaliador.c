#include "..\dstlib_include.h"
 
   // Fun��o para realizar a an�lise lexical
int lexer(char* expressao, Token* tokens) {
	
    int tamanho = 0, i;

    for (i = 0; expressao[i] != '\0'; i++) {
    	
        if (isspace(expressao[i])) continue;
        
        if (isdigit(expressao[i])) {
        	
			
            tokens[tamanho].value = expressao[i];
            tokens[tamanho].type = NUMERO;
            tamanho++;
            
        } else if (expressao[i] == '(' || expressao[i] == ')') {
            tokens[tamanho].value = expressao[i];
            tokens[tamanho].type = PARENTESES;
            tamanho++;
        } else if (expressao[i] == '+' || expressao[i] == '-' || expressao[i] == '*' || expressao[i] == '/' || expressao[i] == '^') {
            tokens[tamanho].value = expressao[i];
            tokens[tamanho].type = OPERADOR;
            tamanho++;
        } else {
        	tokens[tamanho].value = expressao[i];
        	tokens[tamanho].type = NONE;
        	tamanho++;
		}
    }
    return tamanho;
}



// Fun��o para realizar a an�lise sint�tica
int parser(Token* tokens, int tamanho) {
    int i = 0;
    
    while (i < tamanho) {
        // Verificar se � um n�mero
        if (tokens[i].type == NUMERO) {
            int num1 = tokens[i].value - '0'; // Converter caractere para n�mero
            i++;

            // Verificar se � um operador
            if (i < tamanho && tokens[i].type == OPERADOR) {
                char operador = tokens[i].value;
                i++;

                // Verificar se � um n�mero
                if (i < tamanho && tokens[i].type == NUMERO) {
                    int num2 = tokens[i].value - '0'; // Converter caractere para n�mero

                    // Erro: Divisao por zero
                    if (operador == '/' && (( num1 == 0 && num2 == 0) || num2 == 0)) {
                        
                    	 return 0;
                    }
                    // Erro: Potencia de 0^0 invalido!
                    if (operador == '^' && num1 == 0 && num2 == 0) {
                    	                    	
                    	return 1;

                    }
                //Erro: Falta um operando depois do operador
                } else return 3;
       			  
            }
        //Erro: Caracteres invalidos
        } if(tokens[i].type == NONE) return 2; 
          
          
    }
    return -1;
}

//Funcao que mostra o tipo de erro de acordo o retorno a funcao parse.
char* imprimir_erro(int codigo) {
    switch (codigo) {
        case 0:
            return "Erro: Divisao por zero\n";
            break;
        case 1:
            return "Erro: Exponenciacao de zero por zero\n";
            break;
        case 2:
            return "Erro: Caracteres invalidos\n";
            break;
        case 3:
            return "Erro: Falta um operando depois do operador\n";
            break;
        case 4:
            return "Erro: Par�nteses fechados sem abertura\n";
            break;
            case 5:
            return "Erro: Caracteres invalidos\n";
            break;
        default:
            return "Erro desconhecido\n";
            break;
    }
}



int get_precedencia(char operador) {
    switch (operador) {
        case '+':
        case '-':
            return 1;
        case '*':
        case '/':
            return 2;
        case '^':
            return 3;
        default:
            return 0;
    }
}

void shunting_yard(Token* tokens, int tamanho, Fila *fila, Pilha_int *pilha) {
    initFila(fila);
    initPilhaInt(pilha);
	int i;
    for (i = 0; i < tamanho; i++) {
        if (tokens[i].type == NUMERO) {
            inserir(fila, tokens[i]);
        } else if (tokens[i].type == OPERADOR) {
            while (!vaziaPilhaInt(pilha) && pilha->cabeca->valor != '(' && get_precedencia(tokens[i].value) <= get_precedencia(pilha->cabeca->valor)) {
                Token tk;
                tk.value = pilha->cabeca->valor;
                tk.type = OPERADOR;
                inserir(fila, tk);
                pop_int(pilha);
            }
            push_int(pilha, tokens[i].value);
        } else if (tokens[i].type == PARENTESES) {
            if (tokens[i].value == '(') {
                push_int(pilha, tokens[i].value);
            } else if (tokens[i].value == ')') {
                while (!vaziaPilhaInt(pilha) && pilha->cabeca->valor != '(') {
                    Token tk;
                    tk.value = pilha->cabeca->valor;
                    tk.type = OPERADOR;
                    inserir(fila, tk);
                    pop_int(pilha);
                }
                if (!vaziaPilhaInt(pilha) && pilha->cabeca->valor == '(') {
                    pop_int(pilha);
                }
            }
        }
    }

    while (!vaziaPilhaInt(pilha)) {
        Token tk;
        tk.value = pilha->cabeca->valor;
        tk.type = OPERADOR;
        inserir(fila, tk);
        pop_int(pilha);
    }
}

int calcular(Fila *fila) {
    Pilha_int pilha;
    initPilhaInt(&pilha);
	int resultado;
	
    while (!vaziaFila(fila)) {
        Token tk = frente(fila);
        remover(fila);

        if (tk.type == NUMERO) {
            push_int(&pilha, tk.value - '0');
        } else if (tk.type == OPERADOR) {
            int num2 = top_int(&pilha);
            pop_int(&pilha);
            int num1 = top_int(&pilha);
            pop_int(&pilha);

            switch (tk.value) {
                case '+':
                    resultado = num1 + num2;
                    break;
                case '-':
                    resultado = num1 - num2;
                    break;
                case '*':
                    resultado = num1 * num2;
                    break;
                case '/':
                    resultado = num1 / num2;
                    break;
                case '^':
                    resultado = pow(num1,num2);
                    break;
            }
            push_int(&pilha, resultado);
        }
    }

    
    return top_int(&pilha);
}

int main() {
	
	char expressao[MAX];
	Token tokens[MAX];
	Fila fila;
    Pilha_int pilha;
    
    FILE *in;
	FILE *out;
			
	in = fopen("in.txt", "w");
	out = fopen("out.txt", "w");	
	
	if(in == NULL || out == NULL) {
		printf("Erro ao abrir o arquivo\n");
		return 1;
		}
		
		printf("Obs: Se desejas terminar a execucao, por favor deves digitar . para terminar!\n\n");
		while(1) {
	
		printf("Escreva a expressao matematica: ");
		
		fgets(expressao, 100, stdin);
		
		expressao[strcspn(expressao, "\n")] = 0;
		
		int i;
		int j = 0;
		for(i = 0; expressao[i] != '\0'; i++){
	
		if(expressao[i] == '.') {
			j = 1;
			expressao[i] = '\0';
		}	
	}
		fprintf(in, "%s\n\n", expressao);
		
		int tamanho = lexer(expressao, tokens);
		
		if(parser(tokens, tamanho) == -1) {
			
		shunting_yard(tokens, tamanho, &fila, &pilha);
		int resultado = calcular(&fila);
    	fprintf(out, "%d\n\n", resultado);
    	
		}
		
		else fprintf(out, "%s\n\n", imprimir_erro(parser(tokens, tamanho)));

		if(j) {
			break;
		}
}
	fclose(in);
	fclose(out);	
	
	return 0;
}
